<?php get_header(); ?>
<div id='wpwaf_custom_panel'>
    <div id='wpwaf_info_message'>
        <?php echo $message; ?>
    </div>
</div>
<?php get_footer(); ?>

jQuery(document).ready(function($){

	
});

wp.api.loadPromise.done( function() {

	// var post = new wp.api.models.Post( { title: 'This is a REST API post', content: 'REST API post content' } );
	// post.save();

	// var post = new wp.api.models.Post( { id: 282, title: 'Updated REST API post', content: 'Updated REST API post content' } );
	// post.save();

	// var post = new wp.api.models.Post( { id: 280 } );
	// post.fetch();
	// post.destroy();
} );
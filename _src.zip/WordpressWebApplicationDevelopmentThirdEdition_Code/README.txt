Technically, you need a computer, browser, and an Internet connection with the following working environment:
The Apache web server
PHP Version 5.4 or higher
WordPress Version 4.7.2
MySQL Version 5.6 or higher
Once you have the preceding environment, you can download the Responsive theme from http://wordpress. org/themes/responsiveand activate it from the Themes section.
Finally, you can activate the plugin developed for this book to get things started.
Refer to Appendix A, Configurations, Tools, and Resources, for the application setup guide, required software, and plugins.

